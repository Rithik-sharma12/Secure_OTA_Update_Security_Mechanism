/*
 * ESP32 Multi-Method OTA Firmware
 * ─────────────────────────────────────────────────
 * Supports:
 *   1. ArduinoOTA  – push over Wi-Fi (IDE / OTA IDE terminal)
 *   2. GitHub OTA  – self-pull latest release from GitHub
 *   3. Serial/USB  – standard esptool flash (always available)
 *
 * Board : ESP32 (all variants)
 * Core  : arduino-esp32 >= 2.0.0
 * Libs  : ArduinoOTA, HTTPClient, Update, WiFi (all bundled)
 * ─────────────────────────────────────────────────
 */

#include <Arduino.h>
#include <WiFi.h>
#include <ArduinoOTA.h>
#include <HTTPClient.h>
#include <HTTPUpdate.h>
#include <ArduinoJson.h>        // Install: "ArduinoJson" by Benoit Blanchon
#include <Preferences.h>        // NVS storage for health score & settings

#include "ota_config.h"         // secrets – NEVER commit this file

// ── Version (must match your GitHub release tag, e.g. "v2.4.0") ──
#define FIRMWARE_VERSION   "2.4.0"
#define FIRMWARE_VERSION_N  20400   // numeric: major*10000 + minor*100 + patch

// ── Health score thresholds ──────────────────────────────────────
#define HEALTH_QUARANTINE  40
#define HEALTH_WARNING     60
#define HEALTH_MAX        100

// ── Timing ───────────────────────────────────────────────────────
#define GITHUB_CHECK_INTERVAL_MS  (15UL * 60 * 1000)   // 15 min
#define ARDUINO_OTA_PORT           3232

// ── GPIO (adjust to your board) ─────────────────────────────────
#define LED_STATUS  2      // onboard LED
#define BTN_OTA    0       // BOOT button – hold 3 s to trigger GitHub OTA

Preferences prefs;

// ── Runtime state ────────────────────────────────────────────────
struct AppState {
  int   healthScore       = HEALTH_MAX;
  bool  inQuarantine      = false;
  int   failedAttempts24h = 0;
  ulong lastGithubCheck   = 0;
  ulong lastPollSuccess   = 0;
  char  currentVersion[16];
};

AppState state;

// ─────────────────────────────────────────────────────────────────
//  FORWARD DECLARATIONS
// ─────────────────────────────────────────────────────────────────
void setupWiFi();
void setupArduinoOTA();
void checkGithubOTA();
bool fetchLatestRelease(String &tagOut, String &urlOut);
bool performHttpUpdate(const String &url);
void adjustHealth(int delta, const char *reason);
void loadHealth();
void saveHealth();
void blinkLED(int times, int ms = 100);
bool isBtnHeld(int ms);

// ─────────────────────────────────────────────────────────────────
//  SETUP
// ─────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(LED_STATUS, OUTPUT);
  pinMode(BTN_OTA, INPUT_PULLUP);

  Serial.printf("\n[OTA] Firmware v%s starting...\n", FIRMWARE_VERSION);

  loadHealth();
  setupWiFi();

  if (!state.inQuarantine) {
    setupArduinoOTA();
  } else {
    Serial.println("[OTA] Device in quarantine – ArduinoOTA disabled");
    blinkLED(5, 200);
  }

  blinkLED(2);
  Serial.println("[OTA] Setup complete");
}

// ─────────────────────────────────────────────────────────────────
//  LOOP
// ─────────────────────────────────────────────────────────────────
void loop() {
  // Service ArduinoOTA
  if (!state.inQuarantine) {
    ArduinoOTA.handle();
  }

  // Manual GitHub OTA trigger – hold BOOT button 3 s
  if (isBtnHeld(3000)) {
    Serial.println("[OTA] Manual GitHub OTA triggered by button");
    checkGithubOTA();
  }

  // Periodic GitHub OTA check
  ulong now = millis();
  if (now - state.lastGithubCheck >= GITHUB_CHECK_INTERVAL_MS) {
    state.lastGithubCheck = now;

    if (state.inQuarantine) {
      Serial.println("[OTA] Skipping GitHub check – quarantined");
    } else {
      checkGithubOTA();
    }
  }

  // Successful poll tick (once per minute)
  if (now - state.lastPollSuccess >= 60000) {
    state.lastPollSuccess = now;
    adjustHealth(+1, "poll success");
  }

  delay(10);
}

// ─────────────────────────────────────────────────────────────────
//  Wi-Fi
// ─────────────────────────────────────────────────────────────────
void setupWiFi() {
  Serial.printf("[WiFi] Connecting to %s", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  WiFi.setHostname("esp32-ota-device");

  int tries = 0;
  while (WiFi.status() != WL_CONNECTED && tries < 30) {
    delay(500);
    Serial.print(".");
    tries++;
  }

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("\n[WiFi] Failed – rebooting in 10 s");
    adjustHealth(-1, "network error");
    delay(10000);
    ESP.restart();
  }

  Serial.printf("\n[WiFi] Connected – IP: %s\n", WiFi.localIP().toString().c_str());
}

// ─────────────────────────────────────────────────────────────────
//  ArduinoOTA  (push OTA from IDE or OTA IDE terminal)
// ─────────────────────────────────────────────────────────────────
void setupArduinoOTA() {
  ArduinoOTA.setPort(ARDUINO_OTA_PORT);
  ArduinoOTA.setHostname(DEVICE_HOSTNAME);
  ArduinoOTA.setPassword(OTA_PASSWORD);   // set in ota_config.h

  ArduinoOTA.onStart([]() {
    String type = (ArduinoOTA.getCommand() == U_FLASH) ? "firmware" : "filesystem";
    Serial.printf("[ArduinoOTA] Start – %s\n", type.c_str());
    digitalWrite(LED_STATUS, HIGH);
  });

  ArduinoOTA.onEnd([]() {
    Serial.println("[ArduinoOTA] Complete – rebooting");
    adjustHealth(+10, "OTA success");
    blinkLED(5, 80);
  });

  ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
    static int lastPct = -1;
    int pct = (progress * 100) / total;
    if (pct != lastPct) {
      Serial.printf("[ArduinoOTA] %u%%\r", pct);
      lastPct = pct;
    }
    digitalWrite(LED_STATUS, (progress / 1000) % 2);
  });

  ArduinoOTA.onError([](ota_error_t error) {
    const char *msg = "Unknown";
    switch (error) {
      case OTA_AUTH_ERROR:    msg = "Auth Failed";        break;
      case OTA_BEGIN_ERROR:   msg = "Begin Failed";       break;
      case OTA_CONNECT_ERROR: msg = "Connect Failed";     break;
      case OTA_RECEIVE_ERROR: msg = "Receive Failed";     break;
      case OTA_END_ERROR:     msg = "End Failed";         break;
    }
    Serial.printf("[ArduinoOTA] Error[%u]: %s\n", error, msg);
    adjustHealth(-10, "OTA error");
  });

  ArduinoOTA.begin();
  Serial.printf("[ArduinoOTA] Listening on port %d\n", ARDUINO_OTA_PORT);
}

// ─────────────────────────────────────────────────────────────────
//  GitHub OTA  (self-pull latest release)
// ─────────────────────────────────────────────────────────────────
void checkGithubOTA() {
  Serial.println("[GitHub] Checking for firmware update...");

  String latestTag, downloadUrl;
  if (!fetchLatestRelease(latestTag, downloadUrl)) {
    Serial.println("[GitHub] Could not fetch release info");
    adjustHealth(-1, "network error");
    return;
  }

  // Strip leading 'v' for comparison
  String remoteVer = latestTag;
  if (remoteVer.startsWith("v") || remoteVer.startsWith("V")) {
    remoteVer = remoteVer.substring(1);
  }

  Serial.printf("[GitHub] Current: v%s  Remote: %s\n", FIRMWARE_VERSION, remoteVer.c_str());

  if (remoteVer == FIRMWARE_VERSION) {
    Serial.println("[GitHub] Up to date");
    adjustHealth(+1, "poll success");
    return;
  }

  Serial.printf("[GitHub] Update available: %s\n", downloadUrl.c_str());
  Serial.println("[GitHub] Downloading & flashing...");

  if (performHttpUpdate(downloadUrl)) {
    adjustHealth(+10, "update success");
    Serial.println("[GitHub] Update successful – rebooting");
    blinkLED(10, 50);
    delay(500);
    ESP.restart();
  } else {
    Serial.println("[GitHub] Update FAILED");
    state.failedAttempts24h++;
    adjustHealth(-25, "update failed");
  }
}

bool fetchLatestRelease(String &tagOut, String &urlOut) {
  if (WiFi.status() != WL_CONNECTED) return false;

  // GitHub API endpoint – returns JSON for the latest release
  String apiUrl = "https://api.github.com/repos/";
  apiUrl += GITHUB_OWNER;
  apiUrl += "/";
  apiUrl += GITHUB_REPO;
  apiUrl += "/releases/latest";

  HTTPClient http;
  http.begin(apiUrl);
  http.addHeader("User-Agent", "ESP32-OTA/" FIRMWARE_VERSION);
  http.addHeader("Accept", "application/vnd.github.v3+json");

  // Add token for private repos (optional for public)
  if (strlen(GITHUB_TOKEN) > 0) {
    http.addHeader("Authorization", "Bearer " + String(GITHUB_TOKEN));
  }

  http.setTimeout(10000);
  int code = http.GET();

  if (code != 200) {
    Serial.printf("[GitHub] API error %d\n", code);
    http.end();
    return false;
  }

  // Parse JSON – we only need tag_name and the .bin asset URL
  // ArduinoJson 7.x dynamic allocation
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, http.getStream());
  http.end();

  if (err) {
    Serial.printf("[GitHub] JSON parse error: %s\n", err.c_str());
    return false;
  }

  tagOut = doc["tag_name"].as<String>();

  // Find the first .bin asset for this board
  for (JsonObject asset : doc["assets"].as<JsonArray>()) {
    String name = asset["name"].as<String>();
    // Match pattern: firmware-esp32.bin  (adjust to your naming)
    if (name.endsWith(".bin") && name.indexOf("esp32") >= 0) {
      urlOut = asset["browser_download_url"].as<String>();
      return true;
    }
  }

  // Fallback: first .bin found
  for (JsonObject asset : doc["assets"].as<JsonArray>()) {
    String name = asset["name"].as<String>();
    if (name.endsWith(".bin")) {
      urlOut = asset["browser_download_url"].as<String>();
      return true;
    }
  }

  Serial.println("[GitHub] No .bin asset found in release");
  return false;
}

bool performHttpUpdate(const String &url) {
  WiFiClientSecure client;
  client.setInsecure();   // Accept any cert – replace with root CA for production

  // HTTPUpdate provides progress callbacks
  httpUpdate.onStart([]() {
    Serial.println("[HTTPUpdate] Starting download");
    digitalWrite(LED_STATUS, HIGH);
  });

  httpUpdate.onEnd([]() {
    Serial.println("[HTTPUpdate] Download complete");
  });

  httpUpdate.onError([](int err) {
    Serial.printf("[HTTPUpdate] Error %d: %s\n", err, httpUpdate.getLastErrorString().c_str());
  });

  httpUpdate.onProgress([](int cur, int total) {
    static int lastPct = -1;
    if (total > 0) {
      int pct = (cur * 100) / total;
      if (pct != lastPct && pct % 10 == 0) {
        Serial.printf("[HTTPUpdate] %d%%\n", pct);
        lastPct = pct;
      }
    }
    digitalWrite(LED_STATUS, (cur / 10000) % 2);
  });

  httpUpdate.rebootOnUpdate(false);   // We reboot manually after health update

  t_httpUpdate_return ret = httpUpdate.update(client, url);

  digitalWrite(LED_STATUS, LOW);

  switch (ret) {
    case HTTP_UPDATE_FAILED:
      Serial.printf("[HTTPUpdate] FAILED: %s\n", httpUpdate.getLastErrorString().c_str());
      return false;
    case HTTP_UPDATE_NO_UPDATES:
      Serial.println("[HTTPUpdate] No update");
      return false;
    case HTTP_UPDATE_OK:
      Serial.println("[HTTPUpdate] OK");
      return true;
  }
  return false;
}

// ─────────────────────────────────────────────────────────────────
//  Health Score
// ─────────────────────────────────────────────────────────────────
void adjustHealth(int delta, const char *reason) {
  int prev = state.healthScore;
  state.healthScore = constrain(state.healthScore + delta, 0, HEALTH_MAX);

  Serial.printf("[Health] %s: %d %+d → %d\n", reason, prev, delta, state.healthScore);

  if (state.healthScore < HEALTH_QUARANTINE && !state.inQuarantine) {
    state.inQuarantine = true;
    Serial.println("[Health] ⚠ QUARANTINE – score below threshold");
    blinkLED(10, 150);
  }

  if (state.inQuarantine && state.healthScore >= HEALTH_MAX) {
    state.inQuarantine = false;
    Serial.println("[Health] Quarantine lifted after manual reset");
    setupArduinoOTA();
  }

  saveHealth();
}

void loadHealth() {
  prefs.begin("ota-health", false);
  state.healthScore       = prefs.getInt("health", HEALTH_MAX);
  state.inQuarantine      = prefs.getBool("quarantine", false);
  state.failedAttempts24h = prefs.getInt("fails24h", 0);
  prefs.end();

  strlcpy(state.currentVersion, FIRMWARE_VERSION, sizeof(state.currentVersion));
  Serial.printf("[Health] Loaded: score=%d quarantine=%d\n",
    state.healthScore, state.inQuarantine);
}

void saveHealth() {
  prefs.begin("ota-health", false);
  prefs.putInt("health",     state.healthScore);
  prefs.putBool("quarantine", state.inQuarantine);
  prefs.putInt("fails24h",   state.failedAttempts24h);
  prefs.end();
}

// ─────────────────────────────────────────────────────────────────
//  Utilities
// ─────────────────────────────────────────────────────────────────
void blinkLED(int times, int ms) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_STATUS, HIGH);
    delay(ms);
    digitalWrite(LED_STATUS, LOW);
    delay(ms);
  }
}

bool isBtnHeld(int ms) {
  if (digitalRead(BTN_OTA) == HIGH) return false;   // not pressed
  delay(ms);
  return (digitalRead(BTN_OTA) == LOW);
}
