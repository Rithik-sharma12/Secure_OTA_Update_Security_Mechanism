/*
 * ota_config.h  –  SECRETS FILE
 * ──────────────────────────────────────────────────
 * ⚠  Add "ota_config.h" to .gitignore
 *    NEVER commit this file to GitHub
 * ──────────────────────────────────────────────────
 * Copy this template, fill in your values, save as
 * ota_config.h in the same folder as the .ino file.
 */

#pragma once

// ── Wi-Fi ─────────────────────────────────────────
#define WIFI_SSID       "YOUR_WIFI_SSID"
#define WIFI_PASSWORD   "YOUR_WIFI_PASSWORD"

// ── ArduinoOTA ────────────────────────────────────
// Password used when pushing firmware from Arduino IDE / OTA IDE
#define OTA_PASSWORD    "your_ota_password_here"

// Hostname shown in Arduino IDE network ports list
#define DEVICE_HOSTNAME "esp32-ota-device-01"

// ── GitHub ────────────────────────────────────────
// Repository that hosts your firmware releases
#define GITHUB_OWNER    "your-github-username"
#define GITHUB_REPO     "your-repo-name"

// Personal Access Token with repo scope
// Leave empty string "" for public repos (no token needed)
// For private repos: create token at github.com/settings/tokens
#define GITHUB_TOKEN    ""

/*
 * EXAMPLE – public repo, no token:
 *   #define GITHUB_OWNER  "myusername"
 *   #define GITHUB_REPO   "my-esp32-firmware"
 *   #define GITHUB_TOKEN  ""
 *
 * EXAMPLE – private repo:
 *   #define GITHUB_TOKEN  "ghp_xxxxxxxxxxxxxxxxxxxx"
 */
