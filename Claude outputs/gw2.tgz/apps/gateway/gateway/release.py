"""
SecureOTA Edge Gateway — Release, Manifest, and Pipeline Logic
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .config import (
    ALLOWED_DEVICE_TYPES,
    ARTIFACT_DIRS,
    DEFAULT_RELEASE_ARTIFACT,
    FIRMWARE_CACHE_DIR,
    MANIFEST_FILE,
    MAX_RELEASES,
    SIGNING_ALGORITHM,
    SIGNING_KEY_ID,
)
from .crypto import MANIFEST_SIGNATURE_PREFIX, sign_firmware_payload, with_manifest_signature
from .factory import FactoryImageError, validate_factory_image
from .package import PackageError, is_hex_digest, looks_like_secure_package, parse_package
from .state import STATE, push_event_locked, persist_state_locked
from .utils import (
    firmware_download_url,
    normalize_version,
    safe_cache_path,
    sha256_bytes,
    utc_now_iso,
)


def _within_artifact_dirs(path: Path) -> bool:
    return any(path == root or root in path.parents for root in ARTIFACT_DIRS)


def resolve_release_artifact_path(version: str, source_file_path: str | None) -> Path:
    """Locate the firmware .bin artifact for a release.

    A caller-supplied `source_file_path` must resolve (symlinks included) to a
    file inside one of OTA_GATEWAY_ARTIFACT_DIRS. OTA_GATEWAY_RELEASE_ARTIFACT
    is operator configuration and is not restricted.
    """
    candidates: list[Path] = []

    if source_file_path:
        if not ARTIFACT_DIRS:
            raise ValueError(
                'sourceFilePath is disabled. Upload the file to /api/releases/upload, or set '
                'OTA_GATEWAY_ARTIFACT_DIRS to the directories the gateway may read releases from.'
            )
        provided = Path(source_file_path).expanduser()
        if not provided.is_absolute():
            provided = ARTIFACT_DIRS[0] / provided
        provided = provided.resolve()
        if not _within_artifact_dirs(provided):
            raise ValueError('sourceFilePath is outside OTA_GATEWAY_ARTIFACT_DIRS.')
        candidates.append(provided)

    if DEFAULT_RELEASE_ARTIFACT:
        configured = Path(DEFAULT_RELEASE_ARTIFACT.format(version=version)).expanduser()
        if not configured.is_absolute():
            configured = (Path.cwd() / configured).resolve()
        candidates.append(configured)

    for candidate in candidates:
        if candidate.exists() and candidate.is_file() and candidate.suffix.lower() == '.bin':
            return candidate

    checked_paths = ', '.join(str(path) for path in candidates) if candidates else '(none)'
    raise ValueError(
        'Release artifact not found. Provide sourceFilePath in the release payload or set '
        f'OTA_GATEWAY_RELEASE_ARTIFACT. Checked: {checked_paths}'
    )


def load_release_artifact(version: str, source_file_path: str | None) -> tuple[Path, bytes]:
    """Load and validate a release artifact."""
    artifact_path = resolve_release_artifact_path(version, source_file_path)
    artifact_bytes = artifact_path.read_bytes()
    if not artifact_bytes:
        raise ValueError(f'Release artifact {artifact_path} is empty.')
    return artifact_path, artifact_bytes


def build_pipeline(
    release_id: str,
    stages_data: list[dict[str, Any]],
    started_at: datetime,
) -> dict[str, Any]:
    """Assemble a pipeline record from stages that actually executed.

    This used to fabricate four stages with hardcoded durations, all marked
    'success', describing a build that never ran. Every field here is now
    measured or read back from the artifact — including a real integrity
    re-check — and a failed stage is reported as failed.
    """
    stages: list[dict[str, Any]] = []
    total_duration = 0.0
    overall = 'success'

    for entry in stages_data:
        duration = float(entry.get('duration', 0.0))
        total_duration += duration
        if entry.get('status') != 'success':
            overall = 'failed'

        stages.append(
            {
                'id': f"stage-{uuid.uuid4().hex[:8]}",
                'name': entry['name'],
                'status': entry.get('status', 'success'),
                'startTime': entry['startTime'],
                'endTime': entry['endTime'],
                'logs': entry.get('logs', ''),
                'duration': round(duration, 3),
            }
        )

    return {
        'id': f"pipeline-{uuid.uuid4().hex[:10]}",
        'releaseId': release_id,
        'createdAt': started_at.replace(microsecond=0).isoformat(),
        'stages': stages,
        'status': overall,
        'totalDuration': round(total_duration, 3),
    }


def release_is_secure_package(release: dict[str, Any] | None, payload: bytes) -> bool:
    """Whether the artifact served for this release is an encrypted package.

    Taken from the publisher's explicit `securePackage` flag when present,
    because a v1 package is indistinguishable from a plain image by inspection.
    Falls back to the v2 magic, which is reliable.
    """
    flag = (release or {}).get('securePackage')
    if isinstance(flag, bool):
        return flag
    return looks_like_secure_package(payload)


def image_digest_for_release(release: dict[str, Any] | None, payload: bytes) -> str | None:
    """The SHA-256 of the PLAINTEXT firmware image, when the gateway knows it.

    `sha256` in the manifest covers the artifact exactly as served. For a plain
    release that is the firmware image, but for a secure release it covers the
    whole encrypted package — so a device that decrypts before comparing would
    never match it. The firmware reads `imageSha256` for that comparison, and
    this decides what goes in it:

      * whatever the publisher supplied (`tools/create_secure_test_package.py`
        prints it, and the publish API accepts it as `image_sha256`), or
      * `sha256` itself, when the release is not a secure package, or
      * nothing, when it is a package whose plaintext digest was never
        supplied. The gateway does not hold the AES key, so it cannot derive
        the digest, and publishing the wrong one would fail every update. The
        device then falls back to signature-only verification.
    """
    supplied = str((release or {}).get('imageSha256', '') or '').strip().lower()
    if is_hex_digest(supplied):
        return supplied

    if release_is_secure_package(release, payload):
        return None

    return sha256_bytes(payload)


def manifest_for_release_locked(release: dict[str, Any] | None) -> dict[str, Any] | None:
    """Build the signed manifest for an arbitrary release.

    Only the newest release's manifest is kept in STATE, so serving a
    per-architecture manifest means reconstructing older ones from the cached
    binary. The signature is recomputed over the actual bytes on disk, so a
    manifest can never describe a file the gateway no longer has.

    Must be called under STATE_LOCK.
    """
    if not release:
        return None

    version = str(release.get('version', ''))

    # Fast path: the in-memory manifest already describes this release.
    current = STATE.get('manifest')
    if isinstance(current, dict) and str(current.get('version', '')) == version:
        return current

    assets = release.get('assets') or []
    filename = str(assets[0].get('name', '')) if assets else f'firmware_v{version}.bin'

    firmware_path = safe_cache_path(filename)
    if not firmware_path or not firmware_path.exists():
        return None

    payload = firmware_path.read_bytes()
    if not payload:
        return None

    download_url = firmware_download_url(filename)
    image_digest = image_digest_for_release(release, payload)
    manifest = {
        'version': version,
        'filename': filename,
        'sha256': sha256_bytes(payload),
        'size': len(payload),
        'signature': sign_firmware_payload(payload),
        'signatureAlgorithm': SIGNING_ALGORITHM,
        'signatureKeyId': SIGNING_KEY_ID,
        'min_hw_rev': '1.0',
        'generated_at': str(release.get('releaseDate', utc_now_iso())),
        'url': download_url,
        'downloadUrl': download_url,
        'compatible': [str(entry) for entry in release.get('compatible', [])],
    }

    # Omitted rather than guessed when the artifact is a package whose
    # plaintext digest was never published — see image_digest_for_release.
    if image_digest:
        manifest['imageSha256'] = image_digest

    if release_is_secure_package(release, payload):
        manifest['securePackage'] = True

    return with_manifest_signature(manifest)


def latest_release_for_device_locked(device_type: str) -> dict[str, Any] | None:
    """Newest published release whose `compatible` list covers `device_type`.

    Releases are stored newest-first. A release with an empty `compatible`
    list is treated as universal, which keeps releases created before
    compatibility was enforced usable.

    Must be called under STATE_LOCK.
    """
    for release in STATE.get('releases', []):
        if not is_release_published(release):
            continue

        compatible = [str(entry) for entry in release.get('compatible', [])]
        if not compatible or device_type in compatible:
            return release

    return None


def latest_factory_release_locked(device_type: str) -> dict[str, Any] | None:
    """Newest published release for `device_type` that carries a factory image.

    May be older than the newest release: a board brought up on it simply
    updates over the air afterwards. Must be called under STATE_LOCK.
    """
    for release in STATE.get('releases', []):
        if str(release.get('status', 'published')) != 'published' or not release.get('factoryImage'):
            continue
        compatible = [str(entry) for entry in release.get('compatible', [])]
        if not compatible or device_type in compatible:
            return release
    return None


def assigned_release_for_device_locked(device_id: str, device_type: str) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Release that an in-progress deployment is waiting for this device to install.

    Returns (release, deployment). The newest deployment wins when a device is
    pending in more than one. A deployment whose release has since been
    archived or deleted, or no longer covers the device's architecture, is
    skipped rather than served.

    Must be called under STATE_LOCK.
    """
    releases = {str(release.get('id')): release for release in STATE.get('releases', [])}
    for deployment in STATE.get('deployments', []):
        if deployment.get('status') != 'in_progress':
            continue
        target = (deployment.get('targets') or {}).get(device_id)
        if not target or target.get('state') != 'pending':
            continue
        release = releases.get(str(deployment.get('releaseId', '')))
        if not release or str(release.get('status', 'published')) != 'published':
            continue
        compatible = [str(entry) for entry in release.get('compatible', [])]
        if compatible and device_type not in compatible:
            continue
        return release, deployment
    return None, None


def release_for_device_locked(device_id: str | None, device_type: str) -> dict[str, Any] | None:
    """What this device should be running, as far as the gateway is concerned.

    1. A release a dashboard deployment assigned to this device, if any.
    2. Otherwise, with OTA_AUTO_UPDATE on, the newest compatible release.
    3. Otherwise nothing — the device stays on what it has.

    Must be called under STATE_LOCK.
    """
    from .config import AUTO_UPDATE

    if device_id:
        assigned, _deployment = assigned_release_for_device_locked(device_id, device_type)
        if assigned:
            return assigned

    if AUTO_UPDATE:
        return latest_release_for_device_locked(device_type)
    return None


def published_device_types_locked() -> list[str]:
    """Architectures covered by at least one published release.

    Mirrors the matching rule in `latest_release_for_device_locked`: an empty
    `compatible` list is universal, so such a release contributes every allowed
    device type. Used to tell a caller asking for an architecture with nothing
    published what *is* published, instead of a bare 404.

    Must be called under STATE_LOCK.
    """
    found: list[str] = []

    for release in STATE.get('releases', []):
        if str(release.get('status', 'published')) != 'published':
            continue

        compatible = [str(entry) for entry in release.get('compatible', [])]
        for entry in compatible or sorted(ALLOWED_DEVICE_TYPES):
            if entry not in found:
                found.append(entry)

    return found


def create_release_locked(
    version: str,
    description: str,
    changelog: str,
    compatible: list[str],
    source_file_path: str | None = None,
    status: str = 'published',
    inferred_download_count: int = 0,
    artifact_bytes: bytes | None = None,
    artifact_label: str | None = None,
    image_sha256: str | None = None,
    secure_package: bool | None = None,
    factory_bytes: bytes | None = None,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Create a release, manifest, and pipeline. Must be called under STATE_LOCK.

    The firmware payload comes from one of two places:
      * `artifact_bytes` — raw bytes uploaded over HTTP (web UI publish flow).
      * `source_file_path` / OTA_GATEWAY_RELEASE_ARTIFACT — a path on the
        gateway's own filesystem (CLI / automation flow).
    `artifact_bytes` wins when both are supplied.

    `factory_bytes` is an optional merged first-flash image for blank boards
    (see gateway/factory.py). It must contain this release's app image.
    """
    normalized_version = normalize_version(version)

    existing_versions = {str(release.get('version', '')) for release in STATE['releases']}
    if normalized_version in existing_versions:
        raise ValueError(f'Release {normalized_version} already exists.')

    # Each stage below is timed as it runs; the pipeline record is built from
    # these measurements rather than invented.
    pipeline_started = datetime.now(timezone.utc)
    stages_data: list[dict[str, Any]] = []

    def _stage(name: str, begin: datetime, logs: str, status: str = 'success') -> None:
        end = datetime.now(timezone.utc)
        stages_data.append(
            {
                'name': name,
                'status': status,
                'startTime': begin.replace(microsecond=0).isoformat(),
                'endTime': end.replace(microsecond=0).isoformat(),
                'logs': logs,
                'duration': (end - begin).total_seconds(),
            }
        )

    # ── Stage 1: acquire the artifact ──────────────────────────────
    stage_begin = datetime.now(timezone.utc)
    if artifact_bytes is not None:
        if not artifact_bytes:
            raise ValueError('Uploaded firmware artifact is empty.')
        firmware_payload = artifact_bytes
        source_artifact = artifact_label or 'uploaded via web UI'
    else:
        artifact_path, firmware_payload = load_release_artifact(normalized_version, source_file_path)
        source_artifact = str(artifact_path)

    # The gateway key also signs manifest statements (crypto.manifest_signing_message).
    # An artifact that *is* such a statement would come back with a valid
    # manifest signature for fields the operator never published.
    if firmware_payload.startswith(MANIFEST_SIGNATURE_PREFIX.encode('ascii')):
        raise ValueError('This file is not a firmware image.')

    # A secure package that carries a signed version must be published under
    # that version. The device refuses the mismatch anyway; refusing it here
    # turns a fleet-wide failed update into an error at publish time.
    if looks_like_secure_package(firmware_payload):
        try:
            signed_version = parse_package(firmware_payload).version
        except PackageError as exc:
            raise ValueError(f'Secure package is malformed: {exc}') from exc
        if signed_version is not None and normalize_version(signed_version) != normalized_version:
            raise ValueError(
                f'Package is signed for v{signed_version} but is being published as '
                f'v{normalized_version}.'
            )

    checksum = sha256_bytes(firmware_payload)
    _stage(
        'artifact',
        stage_begin,
        f'Received {len(firmware_payload)} bytes from {source_artifact}; sha256={checksum}.',
    )

    # ── Stage 2: persist to the firmware cache ─────────────────────
    stage_begin = datetime.now(timezone.utc)
    filename = f"firmware_v{normalized_version}.bin"
    firmware_path = FIRMWARE_CACHE_DIR / filename
    with open(firmware_path, 'wb') as firmware_file:
        firmware_file.write(firmware_payload)
    _stage('store', stage_begin, f'Wrote {firmware_path.name} to the gateway firmware cache.')

    generated_at = utc_now_iso()
    release_id = f"release-{normalized_version.replace('.', '-')}-{uuid.uuid4().hex[:6]}"

    release = {
        'id': release_id,
        'version': normalized_version,
        'releaseDate': generated_at,
        'description': description,
        'assets': [
            {
                'id': f"asset-{uuid.uuid4().hex[:10]}",
                'name': filename,
                'size': len(firmware_payload),
                'checksum': checksum,
                'createdAt': generated_at,
            }
        ],
        'compatible': compatible,
        'changelog': changelog,
        'downloadCount': inferred_download_count,
        'status': status,
        'sourceArtifact': source_artifact,
    }

    # Carried on the release, not just the manifest: manifest_for_release_locked
    # reconstructs older manifests from the release record, and would otherwise
    # lose the plaintext digest as soon as a newer release superseded this one.
    normalized_image_digest = str(image_sha256 or '').strip().lower()
    if normalized_image_digest:
        if not is_hex_digest(normalized_image_digest):
            raise ValueError('image_sha256 must be 64 hexadecimal characters.')
        release['imageSha256'] = normalized_image_digest

    if secure_package is not None:
        release['securePackage'] = bool(secure_package)
    elif looks_like_secure_package(firmware_payload):
        release['securePackage'] = True

    if factory_bytes is not None:
        try:
            factory_record = validate_factory_image(
                factory_bytes, image_digest_for_release(release, firmware_payload)
            )
        except FactoryImageError as exc:
            raise ValueError(f'Factory image rejected: {exc}') from exc
        factory_name = f"firmware_v{normalized_version}_factory.bin"
        (FIRMWARE_CACHE_DIR / factory_name).write_bytes(factory_bytes)
        release['factoryImage'] = {'name': factory_name, **factory_record}

    # ── Stage 3: sign the manifest ─────────────────────────────────
    stage_begin = datetime.now(timezone.utc)
    signature = sign_firmware_payload(firmware_payload)
    manifest = {
        'version': normalized_version,
        'filename': filename,
        'sha256': checksum,
        'size': len(firmware_payload),
        'signature': signature,
        'signatureAlgorithm': SIGNING_ALGORITHM,
        'signatureKeyId': SIGNING_KEY_ID,
        'min_hw_rev': '1.0',
        'generated_at': generated_at,
        'url': firmware_download_url(filename),
        # The ESP32 firmware reads `downloadUrl` first and only falls back to
        # rebuilding the URL from BACKEND_URL + filename. Emit both keys.
        'downloadUrl': firmware_download_url(filename),
        'compatible': compatible,
    }

    # `sha256` above describes the artifact as served. A secure release serves a
    # package, so the device needs the plaintext digest separately to bind the
    # image it flashes to the version it agreed to install.
    image_digest = image_digest_for_release(release, firmware_payload)
    if image_digest:
        manifest['imageSha256'] = image_digest

    # Lets a device without secure keys refuse a package outright rather than
    # flashing ciphertext and relying on the image-magic check to save it.
    if release_is_secure_package(release, firmware_payload):
        manifest['securePackage'] = True

    # Ed25519 over version, sha256, imageSha256 and size: what a device checks
    # at stage 5 (or asks the gateway to check, on an ATmega328P).
    manifest = with_manifest_signature(manifest)

    _stage(
        'sign',
        stage_begin,
        f'Manifest signed with {SIGNING_ALGORITHM} key {SIGNING_KEY_ID}; '
        f'targets={", ".join(compatible) or "all"}.',
    )

    # ── Stage 4: verify what was actually written to disk ──────────
    # A genuine integrity check: read the cached file back and confirm it
    # hashes to the value published in the manifest. Catches a truncated or
    # corrupted write before any device downloads it.
    stage_begin = datetime.now(timezone.utc)
    try:
        written_back = firmware_path.read_bytes()
        readback_checksum = sha256_bytes(written_back)
        if readback_checksum == checksum and len(written_back) == len(firmware_payload):
            _stage(
                'verify',
                stage_begin,
                f'Re-read {len(written_back)} bytes from cache; sha256 matches the signed manifest.',
            )
        else:
            _stage(
                'verify',
                stage_begin,
                f'Integrity mismatch: cache sha256={readback_checksum} '
                f'({len(written_back)} bytes) vs manifest {checksum} '
                f'({len(firmware_payload)} bytes).',
                status='failed',
            )
            raise ValueError(
                'Firmware failed post-write integrity check; release not published.'
            )
    except OSError as error:
        _stage('verify', stage_begin, f'Could not re-read cached firmware: {error}', status='failed')
        raise ValueError(f'Firmware cache is unreadable: {error}') from error

    pipeline = build_pipeline(release_id, stages_data, pipeline_started)

    STATE['releases'].insert(0, release)
    STATE['releases'] = STATE['releases'][:MAX_RELEASES]
    STATE['manifest'] = manifest
    STATE['pipeline'] = pipeline

    with open(MANIFEST_FILE, 'w', encoding='utf-8') as manifest_file:
        json.dump(manifest, manifest_file, indent=2)

    push_event_locked(
        event_type='deployment',
        severity='success',
        title='Release Published',
        description=f"Firmware v{normalized_version} published with {len(compatible)} target architecture(s).",
    )

    return release, manifest, pipeline


def is_release_published(release: dict[str, Any] | None) -> bool:
    return bool(release) and str(release.get('status', 'published')) == 'published'


def newest_published_release_locked() -> dict[str, Any] | None:
    """Newest release that is still offered to devices. Must hold STATE_LOCK."""
    for release in STATE.get('releases', []):
        if is_release_published(release):
            return release
    return None


def refresh_global_manifest_locked() -> dict[str, Any] | None:
    """Point the global manifest at the newest published release.

    The unidentified `/releases/latest/manifest` answer is served from
    STATE['manifest'] and MANIFEST_FILE. After a release is archived (or
    restored) both must follow, or a device that polls without identifying
    itself would still be offered the archived image. With nothing published,
    both are cleared and that endpoint returns 404.

    Must be called under STATE_LOCK.
    """
    release = newest_published_release_locked()
    current = STATE.get('manifest')
    # The fast path in manifest_for_release_locked would hand back the current
    # manifest when versions match; that is only right if it is still published.
    if release is None:
        manifest = None
    elif isinstance(current, dict) and str(current.get('version', '')) == str(release.get('version', '')):
        manifest = current
    else:
        STATE['manifest'] = None
        manifest = manifest_for_release_locked(release)

    STATE['manifest'] = manifest
    if manifest:
        with open(MANIFEST_FILE, 'w', encoding='utf-8') as manifest_file:
            json.dump(manifest, manifest_file, indent=2)
    else:
        try:
            MANIFEST_FILE.unlink()
        except FileNotFoundError:
            pass
    return manifest


def set_release_status_locked(release_id: str, status: str) -> dict[str, Any]:
    """Archive or restore a release. Raises KeyError when it does not exist.

    An archived release is kept (record and cached binary) so it can be
    restored, but it is never offered: manifest selection, the deployment
    endpoints and pending deployment targets all skip non-published releases.

    Must be called under STATE_LOCK.
    """
    if status not in {'published', 'archived'}:
        raise ValueError(f'Unsupported release status {status!r}.')

    release = next((r for r in STATE.get('releases', []) if str(r.get('id')) == release_id), None)
    if release is None:
        raise KeyError(release_id)

    release['status'] = status
    if status == 'archived':
        release['archivedAt'] = utc_now_iso()
    else:
        release.pop('archivedAt', None)

    refresh_global_manifest_locked()
    push_event_locked(
        event_type='deployment',
        severity='warning' if status == 'archived' else 'info',
        title='Release Archived' if status == 'archived' else 'Release Restored',
        description=(
            f"Firmware v{release.get('version', 'unknown')} "
            + ('is no longer offered to devices.' if status == 'archived' else 'is offered to devices again.')
        ),
    )
    return release


def rerun_pipeline_locked(release: dict[str, Any]) -> dict[str, Any]:
    """Re-verify a published release's cached artifact, stage by stage.

    Nothing is rebuilt (the gateway does not compile firmware). The re-run
    reads the cached binary back, checks it against the checksum recorded at
    publish time, and re-signs it to prove the signing key still works. Each
    stage reports what it actually found. Must be called under STATE_LOCK.
    """
    started = datetime.now(timezone.utc)
    stages: list[dict[str, Any]] = []

    def _stage(name: str, begin: datetime, logs: str, status: str = 'success') -> None:
        end = datetime.now(timezone.utc)
        stages.append(
            {
                'name': name,
                'status': status,
                'startTime': begin.replace(microsecond=0).isoformat(),
                'endTime': end.replace(microsecond=0).isoformat(),
                'logs': logs,
                'duration': (end - begin).total_seconds(),
            }
        )

    assets = release.get('assets') or []
    filename = str(assets[0].get('name', '')) if assets else ''
    expected = str(assets[0].get('checksum', '')) if assets else ''

    begin = datetime.now(timezone.utc)
    path = safe_cache_path(filename) if filename else None
    payload = b''
    if not path or not path.is_file():
        _stage('artifact', begin, f'Cached artifact {filename or "(none recorded)"} is missing.', status='failed')
    else:
        payload = path.read_bytes()
        _stage('artifact', begin, f'Read {len(payload)} bytes from {path.name}.')

    if payload:
        begin = datetime.now(timezone.utc)
        actual = sha256_bytes(payload)
        if expected and actual != expected:
            _stage('verify', begin, f'Integrity mismatch: cache sha256={actual}, recorded {expected}.', status='failed')
        else:
            _stage('verify', begin, f'sha256={actual} matches the value recorded at publish time.')

        begin = datetime.now(timezone.utc)
        try:
            sign_firmware_payload(payload)
            _stage('sign', begin, f'Artifact re-signed with {SIGNING_ALGORITHM} key {SIGNING_KEY_ID}.')
        except Exception as error:  # noqa: BLE001 - reported as a failed stage
            _stage('sign', begin, f'Signing failed: {error}', status='failed')

    return build_pipeline(str(release.get('id')), stages, started)
